import { test as base, expect, type Page } from '@playwright/test';

// Defina o tipo do fixture
type MyFixtures = {
  login: Page;
};

// Crie o fixture
export const test = base.extend<MyFixtures>({
  // O nome do fixture será "login"
  login: async ({ page }, use) => {
    await page.goto('http://localhost:5173/');

    // Expect a title "to contain" a substring.
    await expect(page.getByRole('heading', { name: 'Faça o login' })).toBeVisible();
    await expect(page.getByLabel('Email')).toBeVisible();
    await expect(page.getByLabel('Senha')).toBeVisible();
    await expect(page.getByTestId('email-input')).toBeVisible();
    await expect(page.getByTestId('password-input')).toBeVisible();
    await expect(page.getByTestId('submit-button')).toBeVisible();
  
    // Fazer login
    await page.getByTestId('email-input').fill('eduardo.burko@gmail.com');
    await page.getByTestId('password-input').fill('123456');
    await page.getByTestId('submit-button').click();
  
    // Esperar o carregamento da página
    await page.waitForURL('http://localhost:5173/authenticated/customers');
    // Disponibilize a página já logada para os testes
    await use(page);
  },
});
export { expect };