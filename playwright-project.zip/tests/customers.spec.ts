import {test, expect} from '../fixtures';

// Testar se existe uma tabela com lista de clientes na tela
test.skip('Jornada complete de login bem sucedido', async ({login}) => {
    // Verificar se o login foi bem sucedido
    await expect(login.getByRole('heading', { name: 'Página dos clientes' })).toBeVisible();

    await expect(login.getByRole('columnheader', { name: 'Nome' })).toBeVisible();

    await login.locator('th', {has: login.getByText('Nome')}).isVisible();
    await expect(login.getByTestId('table-customers')).toBeVisible();
    await expect(login.getByTestId('spinner-customers')).toBeVisible();

    await login.waitForTimeout(5000);

    const rows = await login.locator('tbody tr').count();

    expect(rows).toBeGreaterThan(0);

    await expect(login.getByTestId('pagination')).toBeVisible();
})

test('deve fazer login e criar um cliente', async ({ login }) => {
    // O fixture login já executou o login para você
    // Agora você pode fazer outras ações, como criar um cliente:
    await login.getByTestId('new-customer-button').click()
    await expect(login.getByTestId('drawer')).toBeVisible();
    await login.getByTestId('name-input').fill('Jaspion Silva');
    await login.getByTestId('document-input').fill('032.954.789-50');
    await login.getByTestId('phone-input').fill('41997602541');
    await login.getByTestId('email-input').fill('eduardo.burko@gmail.com');
    await login.locator('tbody tr').count();
    await login.getByTestId('cep-input').fill('81170370');
    await login.getByTestId('status-input').click();
    await login.getByRole('option', { name: 'Ativo', exact: true }).click();
    await login.waitForTimeout(4000);
    await expect(login.getByTestId('address-input')).not.toBeEmpty();
    await expect(login.getByTestId('city-input')).not.toBeEmpty();
    await expect(login.getByTestId('state-input')).not.toBeEmpty();
    await login.getByTestId('submit-button').click();
    await login.getByText('Cadastro efetuado com sucesso!').waitFor({ state: 'visible' });
  });