import { test, expect } from '@playwright/test';

test('Jornada complete de login bem sucedido', async ({ page }) => {
  await page.goto('http://localhost:5173/');

  // Expect a title "to contain" a substring.
  await expect(page.getByRole('heading', { name: 'Faça o login' })).toBeVisible();
  await expect(page.getByLabel('Email')).toBeVisible();
  await expect(page.getByLabel('Senha')).toBeVisible();
  await expect(page.getByTestId('email-input')).toBeVisible();
  await expect(page.getByTestId('password-input')).toBeVisible();
  await expect(page.getByTestId('submit-button')).toBeVisible();

  // Fazer login
  await page.getByTestId('email-input').fill('eduardo.burko@gmail.com');
  await page.getByTestId('password-input').fill('123456');
  await page.getByTestId('submit-button').click();

  // Esperar o carregamento da página
  await page.waitForURL('http://localhost:5173/authenticated/customers');

  // Verificar se o login foi bem sucedido
  await expect(page.getByRole('heading', { name: 'Página dos clientes' })).toBeVisible();
});

test('Jornada para testar se o usuário tentar fazer login com os campos vazio', async ({page})=>{
  await page.goto('http://localhost:5173/');

  // Esperar o carregamento da página
  await expect(page.getByRole('heading', { name: 'Faça o login' })).toBeVisible();
  await expect(page.getByLabel('Email')).toBeVisible();
  await expect(page.getByLabel('Senha')).toBeVisible();
  await expect(page.getByTestId('email-input')).toBeVisible();
  await expect(page.getByTestId('password-input')).toBeVisible();
  await expect(page.getByTestId('submit-button')).toBeVisible();

  // Fazer login
  await page.getByTestId('email-input').fill('');
  await page.getByTestId('password-input').fill('');
  await page.getByTestId('submit-button').click();

  // Verificar se existe as mensagens de erro na tela escrito Campo obrigatório
  await expect(page.getByText('Campo obrigatório')).toHaveCount(2);
})